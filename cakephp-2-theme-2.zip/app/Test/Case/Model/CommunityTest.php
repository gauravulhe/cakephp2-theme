<?php
App::uses('Community', 'Model');

/**
 * Community Test Case
 */
class CommunityTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.community',
		'app.gotra',
		'app.member'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Community = ClassRegistry::init('Community');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Community);

		parent::tearDown();
	}

}

<?php
App::uses('Gotra', 'Model');

/**
 * Gotra Test Case
 */
class GotraTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.gotra',
		'app.community',
		'app.member'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Gotra = ClassRegistry::init('Gotra');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Gotra);

		parent::tearDown();
	}

}

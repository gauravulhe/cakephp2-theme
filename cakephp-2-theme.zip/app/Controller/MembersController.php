<?php
App::uses('AppController', 'Controller');
/**
 * Members Controller
 *
 * @property Member $Member
 * @property PaginatorComponent $Paginator
 */
class MembersController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');
	public $uses = array('Member', 'Country', 'State', 'City', 'Community', 'Gotra');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Member->recursive = 0;
		$this->set('members', $this->Paginator->paginate());		
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Member->exists($id)) {
			throw new NotFoundException(__('Invalid member'));
		}
		$options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
		$this->set('member', $this->Member->find('first', $options));

		// country code
		$code = $this->Member->find('first', array('conditions' => array('Member.id' => $id), array('fields' => array('Member.country_id', 'Member.state_id', 'Member.city_id'))));

		$countries = $this->Country->find('first', array('conditions' => array('Country.id' => $code['Member']['country_id']), 'fields' => 'Country.country'));		
		$this->set('country', $countries['Country']['country']);

		// state code
		$states = $this->State->find('first', array('conditions' => array('State.id' => $code['Member']['state_id']), 'fields' => 'State.state'));		
		$this->set('state', $states['State']['state']);

		// city code
		$cities = $this->City->find('first', array('conditions' => array('City.id' => $code['Member']['city_id']), 'fields' => 'City.city'));
		$this->set('city', $cities['City']['city']);

	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			//debug($this->request->data);exit;
			$this->Member->create();
			if ($this->Member->save($this->request->data)) {
				$this->Flash->success(__('The member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The member could not be saved. Please, try again.'));
			}
		}

		$countries = $this->Country->find('list', array('fields' => array('id', 'country')));
		$this->set('country', $countries);

		$states = $this->State->find('list', array('fields' => array('id', 'state')));
		$this->set('state', $states);

		$cities = $this->City->find('list', array('fields' => array('id', 'city')));
		$this->set('city', $cities);

		$communities = $this->Community->find('list', array('fields' => array('id', 'samaj')));
		$this->set('community', $communities);
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Member->exists($id)) {
			throw new NotFoundException(__('Invalid member'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Member->save($this->request->data)) {
				$this->Flash->success(__('The member has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Flash->error(__('The member could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Member.' . $this->Member->primaryKey => $id));
			$this->request->data = $this->Member->find('first', $options);
		
			// State, City Id
			$code = $this->Member->find('first', array('conditions' => array('Member.id' => $id), array('fields' => array('Member.country_id', 'Member.state_id', 'Member.city_id'))));

			$countries = $this->Country->find('list', array('fields' => array('id', 'country')));
			$this->set('country', $countries);

			$stateId = $code['Member']['state_id'];
			$states = $this->State->find('list', array('conditions' => array('State.id' => $stateId), 'fields' => array('id', 'state')));
			$this->set('state', $states);

			$cityId = $code['Member']['city_id'];
			$cities = $this->City->find('list', array('conditions' => array('City.id' => $cityId), 'fields' => array('id', 'city')));
			$this->set('city', $cities);
		}

	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Member->id = $id;
		if (!$this->Member->exists()) {
			throw new NotFoundException(__('Invalid member'));
		}
		$this->request->allowMethod('post', 'delete');
		if ($this->Member->delete()) {
			$this->Flash->success(__('The member has been deleted.'));
		} else {
			$this->Flash->error(__('The member could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}


/*
	ajax load state method
*/

	public function ajax_load_state($country_id){
		if (!empty($country_id)) {

			$states = $this->State->find('list', array('conditions' => array('State.country_id' => $country_id), 'fields' => array('State.id', 'State.state')));

			$data = '';

			if (!empty($states)) {
				
				$data .= '<select name="data[Member][state_id]" id="state_id" onchange="load_city(this.value);" required="required">';
				$data .= "<option value=''>Select</option>";

				foreach ($states as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';	

			}else{
				$data .= '<select name="data[Member][state_id]" id="state_id" onchange="load_city(this.value);" required="required">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';				
			}

			echo $data;
			exit;
		}
	}


/*
	ajax load city method
*/

	public function ajax_load_city($state_id){
		if (!empty($state_id)) {

			$cities = $this->City->find('list', array('conditions' => array('City.state_id' => $state_id), 'fields' => array('City.id', 'City.city')));

			$data = '';

			if (!empty($cities)) {
				
				$data .= '<select name="data[Member][city_id]" id="city_id" required="required">';
				$data .= "<option value=''>Select</option>";

				foreach ($cities as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';	

			}else{
				$data .= '<select name="data[Member][city_id]" id="city_id" required="required">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';				
			}

			echo $data;
			exit;
		}
	}


/*
	ajax load gotra method
*/

	public function ajax_load_gotra($community_id){
		if (!empty($community_id)) {

			$gotras = $this->Gotra->find('list', array('conditions' => array('Gotra.community_id' => $community_id), 'fields' => array('Gotra.id', 'Gotra.gotra')));

			$data = '';

			if (!empty($gotras)) {
				
				$data .= '<select name="data[Member][gotra_id]" id="gotra_id" onchange="load_other_gotra(this.value);" required="required">';
				$data .= "<option value=''>Select</option>";

				foreach ($gotras as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';	

			}else{
				$data .= '<select name="data[Member][gotra_id]" id="gotra_id" required="required">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';				
			}

			echo $data;
			exit;
		}
	}


/*
	ajax load other gotra method
*/

	public function ajax_load_other_gotra($gotra_id){
		if (!empty($gotra_id)) {

			$communityId = $this->Gotra->find('first', array('conditions' => array('Gotra.id' => $gotra_id), 'fields' => array('community_id')));
			$community_id = $communityId['Gotra']['community_id'];

			$gotras = $this->Gotra->find('list', array('conditions' => array('Gotra.community_id' => $community_id), 'fields' => array('Gotra.id', 'Gotra.gotra')));

			$data = '';

			if (!empty($gotras)) {
				
				$data .= '<select name="data[Member][gotra_id]" id="gotra_id" required="required">';
				$data .= "<option value=''>Select</option>";

				foreach ($gotras as $key => $value) {
					$data .= '<option value='.$key.'>'.$value.'</option>';
				}

				$data .= '</select>';	

			}else{
				$data .= '<select name="data[Member][other_gotra_id]" id="other_gotra_id" required="required">';
				$data .= "<option value=''>Not Found</option>";
				$data .= '</select>';				
			}

			echo $data;
			exit;
		}
	}

}
